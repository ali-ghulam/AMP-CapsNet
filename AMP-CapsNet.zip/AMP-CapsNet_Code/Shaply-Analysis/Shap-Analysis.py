# -*- coding: utf-8 -*-
"""
Created on Tue Jan 28 22:46:02 2025

@author: Ali-Ghulam
"""


# Evaluate the model
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"Model Accuracy: {accuracy * 100:.2f}%")

# Initialize SHAP explainer
explainer = shap.TreeExplainer(model)

# Compute SHAP values for the test set
shap_values = explainer.shap_values(X_test)

# Visualize SHAP summary plot
plt.title("SHAP Summary Plot")
shap.summary_plot(shap_values[1], X_test)  # Use shap_values[1] for positive class if binary classification

# Visualize SHAP feature importance
plt.title("SHAP Feature Importance")
shap.summary_plot(shap_values[1], X_test, plot_type="bar")
