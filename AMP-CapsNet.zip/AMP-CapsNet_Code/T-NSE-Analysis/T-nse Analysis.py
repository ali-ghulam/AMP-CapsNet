# -*- coding: utf-8 -*-
"""
Created on Wed Jan 29 19:13:54 2025

@author: Ali-Ghulam




"""
# **Step 4: Apply t-SNE for Dimensionality Reduction**
tsne = TSNE(n_components=2, perplexity=30, random_state=42)
X_embedded = tsne.fit_transform(X_scaled)
