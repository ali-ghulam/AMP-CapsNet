#AMP-CapsNet

AMP-CapsNet: A Multi-View Feature Fusion Approach for Antimicrobial Peptide Prediction using Capsule Networks
Prediction of novel AMP-CapsNet, A Multi-View Feature Fusion Approach for Antimicrobial Peptide.<br>

