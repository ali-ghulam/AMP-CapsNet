
# Import Datasets
# Initialise the Scaler
# To scale data
# Split the dataset into features (X) and labels (y)
# Split into training and test set



# Define a custom Capsule layer
class CapsuleLayer(layers.Layer):
    def __init__(self, num_capsules, dim_capsules, routings=3, **kwargs):
        super(CapsuleLayer, self).__init__(**kwargs)
        self.num_capsules = num_capsules
        self.dim_capsules = dim_capsules
        self.routings = routings

    def build(self, input_shape):
        self.kernel = self.add_weight(shape=(input_shape[-1], self.num_capsules * self.dim_capsules),
                                      initializer='glorot_uniform',
                                      name='kernel')

    def call(self, inputs):
        inputs_hat = tf.linalg.matmul(inputs, self.kernel)
        inputs_hat = tf.reshape(inputs_hat, (-1, inputs.shape[1], self.num_capsules, self.dim_capsules))
        inputs_hat = tf.transpose(inputs_hat, perm=[0, 2, 1, 3])

        b = tf.zeros_like(inputs_hat[:, :, :, 0])
        for i in range(self.routings):
            c = tf.nn.softmax(b, axis=1)
            s = tf.reduce_sum(c[..., tf.newaxis] * inputs_hat, axis=2)
            v = self.squash(s)
            if i < self.routings - 1:
                b += tf.reduce_sum(inputs_hat * v[:, :, tf.newaxis, :], axis=-1)
        return v

    def squash(self, s):
        s_squared_norm = tf.reduce_sum(tf.square(s), axis=-1, keepdims=True)
        scale = s_squared_norm / (1 + s_squared_norm) / tf.sqrt(s_squared_norm + tf.keras.backend.epsilon())
        return scale * s

# Define the Capsule Network model

# Initial Conv1D layer
x = layers.Conv1D(64, 1, activation='relu')(inputs)
x = layers.MaxPooling1D(pool_size=2)(x)

# Second Conv1D layer
x = layers.Conv1D(64, 6, activation='relu')(x)
x = layers.MaxPooling1D(pool_size=2)(x)
# Third Conv1D layer
x = layers.Conv1D(32, 1, activation='relu')(x)
x = layers.MaxPooling1D(pool_size=2)(x)

# Flatten layer
x = layers.Flatten()(x)

# Primary Capsule layer
x = layers.Dense(128)(x)
x = layers.Reshape((-1, 8))(x)

# Capsule layer
capsules = CapsuleLayer(num_capsules=10, dim_capsules=20)(x)

# Output layer
capsules = layers.Flatten()(capsules)
outputs = layers.Dense(1, activation='sigmoid')(capsules)

model_capsnet = models.Model(inputs, outputs)

# Compile the model
model_capsnet.compile(optimizer=optimizers.RMSprop(),
                      loss=losses.BinaryCrossentropy(),
                      metrics=['accuracy'])

model_capsnet.summary()
